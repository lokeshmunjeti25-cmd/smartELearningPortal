<html>
<head>
<title>Web-Based Central Learning Repository Portal</title>
</head>

<body bgcolor="lightblue">

<h1>Project Successfully Running on Public Server</h1>

<h2>Web-Based Central Learning Repository Portal</h2>

</body>
</html>